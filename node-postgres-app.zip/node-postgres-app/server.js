const express = require('express');
const apiRoutes = require('./routes/api');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use('/api', apiRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

app.get('/', (req, res) => {
    res.send('Welcome to the Node.js + PostgreSQL App!');
});
app.post('/api/items', async (req, res) => {
    const { name } = req.body;
    try {
        const newItem = await pool.query('INSERT INTO items (name) VALUES ($1) RETURNING *', [name]);
        res.json(newItem.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Database error' });
    }
});

