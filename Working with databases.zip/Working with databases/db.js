const mysql = require('mysql2');

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost', // XAMPP default
  user: 'root',      // Default XAMPP username
  password: '',      // Default XAMPP password (leave blank)
  database: 'dummy_db', // Your database name
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err.message);
    return;
  }
  console.log('Connected to the MySQL database!');
});

module.exports = connection;
