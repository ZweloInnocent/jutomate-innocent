const connection = require('./db');

// Insert a dummy user
const insertUser = `INSERT INTO users (name, email) VALUES (?, ?)`;
connection.query(insertUser, ['John Doe', 'john.doe@example.com'], (err, results) => {
  if (err) {
    console.error('Error inserting data:', err.message);
    return;
  }
  console.log('Data inserted:', results);
});

// Retrieve all users
const getUsers = `SELECT * FROM users`;
connection.query(getUsers, (err, results) => {
  if (err) {
    console.error('Error retrieving data:', err.message);
    return;
  }
  console.log('Users:', results);
});
