Choose a Database
First, decide which type of database you want to use:
•	SQL Databases: MySQL, PostgreSQL, SQLite, etc.
•	NoSQL Databases: MongoDB, Redis, Firebase, etc.
	I’m Choosing SQL Database – using XAMPP
Start XAMPP
 
Set Up MySQL Database in XAMPP
1.	Start XAMPP and enable the MySQL and Apache services.
2.	Open phpMyAdmin (http://localhost/phpmyadmin) in your browser.
3.	Create a new database named dummy_db (or any name you prefer).
    - use the databse in your database inside the project
4.	Create a sample table in the database (e.g., users)
 

2. Create a Node.js Project
Open a terminal and navigate to your project directory.
Initialize a new Node.js project:
Bash: 
 
Install the mysql2 package:
 


Create the Database Connection
Create a file named db.js in your project directory to handle the MySQL connection.
 
Set Up the Project to Use the Connection
Create an app.js file to interact with the database.
 

Run App.js: node app.js
 

Check your Database
 
