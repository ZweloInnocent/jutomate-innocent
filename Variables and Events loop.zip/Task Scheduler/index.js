// index.js

const { scheduleTasks } = require('./tasks');

// Global variable for the task list
const tasks = ['Clean Room', 'Wash Dishes', 'Write Code', 'Read Book'];

console.log('Task Scheduler Starting...');
console.log('--------------------------------');

// Demonstrating event loop behavior
setTimeout(() => {
    console.log('Timeout callback executed.');
}, 1000);

setImmediate(() => {
    console.log('Immediate callback executed.');
});

Promise.resolve().then(() => {
    console.log('Promise resolved.');
});

// Schedule tasks asynchronously
scheduleTasks(tasks);

console.log('All tasks scheduled!');
console.log('--------------------------------');
