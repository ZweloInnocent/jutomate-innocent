// tasks.js

// Global variable in this module
const defaultTaskName = 'Default Task';

// Exported function to execute a task
function executeTask(taskName = defaultTaskName) {
    const startTime = Date.now(); // Block-scoped variable
    console.log(`[${taskName}] Started at ${startTime}`);

    // Simulate an asynchronous task
    setTimeout(() => {
        const endTime = Date.now(); // Block-scoped variable
        console.log(`[${taskName}] Completed at ${endTime}`);
        console.log(`[${taskName}] Duration: ${endTime - startTime}ms`);
    }, Math.random() * 2000); // Random delay
}

// Export a function to schedule multiple tasks
function scheduleTasks(taskList) {
    console.log('Scheduling tasks...');
    taskList.forEach((task, index) => {
        const taskName = `Task-${index + 1}: ${task}`; // Block-scoped variable
        executeTask(taskName);
    });
}

module.exports = { executeTask, scheduleTasks };
